#!/usr/bin/env bash
# =============================================================================
# service-restart-tamer.sh — Safely restart a service with health checks
# Free tool from Pragmatic Sysadmin
# https://pragmaticsysadmin.help/shop/
# =============================================================================
# Usage:
#   ./service-restart-tamer.sh nginx
#   ./service-restart-tamer.sh postgresql --wait 30
#   ./service-restart-tamer.sh my-app --pre-check "curl -s http://localhost:8080/health"
#
# What it does:
#   1. Runs a pre-check (optional command) and records state
#   2. Restarts the service via systemctl
#   3. Waits for the service to be active
#   4. Runs the post-check to verify everything's OK
#   5. Auto-rolls back if post-check fails (saves snapshot first)
# =============================================================================

set -euo pipefail

SERVICE=""
PRE_CHECK=""
POST_CHECK=""
WAIT_SECONDS=15

while [[ $# -gt 0 ]]; do
  case "$1" in
    --pre-check) PRE_CHECK="$2"; shift 2 ;;
    --post-check) POST_CHECK="$2"; shift 2 ;;
    --wait) WAIT_SECONDS="$2"; shift 2 ;;
    -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
    --) shift; break ;;
    -*) echo "Unknown flag: $1"; exit 1 ;;
    *) SERVICE="$1"; shift ;;
  esac
done

if [[ -z "$SERVICE" ]]; then
  echo "Usage: $0 <service-name> [--pre-check 'cmd'] [--post-check 'cmd'] [--wait SECONDS]"
  exit 1
fi

if ! command -v systemctl >/dev/null 2>&1; then
  echo "Error: systemctl not found. This script requires systemd."
  exit 1
fi

if [[ $EUID -ne 0 ]]; then
  echo "Note: not running as root. systemctl may need sudo."
fi

# Colors
if [[ -t 1 ]]; then
  RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'
else
  RED=''; YELLOW=''; GREEN=''; BLUE=''; NC=''
fi

echo "════════════════════════════════════════════════════════════════════"
echo " Service Restart Tamer — $SERVICE"
echo " $(date)"
echo "════════════════════════════════════════════════════════════════════"
echo ""

# Step 1: Pre-check
echo -e "${BLUE}[1/5]${NC} Pre-check (current state)..."
if systemctl is-active --quiet "$SERVICE"; then
  echo -e "  ${GREEN}✓${NC} $SERVICE is currently active"
  PRE_ACTIVE=true
else
  echo -e "  ${YELLOW}!${NC} $SERVICE is NOT currently active (will start fresh)"
  PRE_ACTIVE=false
fi

if [[ -n "$PRE_CHECK" ]]; then
  echo "  Running pre-check: $PRE_CHECK"
  if eval "$PRE_CHECK" > /tmp/pre-check-$$.out 2>&1; then
    echo -e "  ${GREEN}✓${NC} Pre-check passed"
    cat /tmp/pre-check-$$.out | sed 's/^/    /'
  else
    echo -e "  ${RED}✗${NC} Pre-check FAILED — aborting restart"
    cat /tmp/pre-check-$$.out | sed 's/^/    /'
    rm -f /tmp/pre-check-$$.out
    exit 1
  fi
  rm -f /tmp/pre-check-$$.out
fi
echo ""

# Step 2: Capture service state for rollback
echo -e "${BLUE}[2/5]${NC} Capturing service state for rollback..."
MAIN_PID=$(systemctl show -p MainPID --value "$SERVICE" 2>/dev/null || echo "0")
UPTIME=$(systemctl show -p ActiveEnterTimestamp --value "$SERVICE" 2>/dev/null || echo "unknown")
echo "  Main PID: $MAIN_PID"
echo "  Started:  $UPTIME"
echo ""

# Step 3: Restart
echo -e "${BLUE}[3/5]${NC} Restarting $SERVICE..."
if systemctl restart "$SERVICE"; then
  echo -e "  ${GREEN}✓${NC} Restart command succeeded"
else
  echo -e "  ${RED}✗${NC} Restart command FAILED"
  exit 1
fi
echo ""

# Step 4: Wait for service to come back up
echo -e "${BLUE}[4/5]${NC} Waiting for $SERVICE to become active (up to ${WAIT_SECONDS}s)..."
WAITED=0
while [[ $WAITED -lt $WAIT_SECONDS ]]; do
  if systemctl is-active --quiet "$SERVICE"; then
    NEW_PID=$(systemctl show -p MainPID --value "$SERVICE" 2>/dev/null || echo "0")
    echo -e "  ${GREEN}✓${NC} Service active after ${WAITED}s (new PID: $NEW_PID)"
    break
  fi
  sleep 1
  WAITED=$((WAITED + 1))
  printf "."
done

if ! systemctl is-active --quiet "$SERVICE"; then
  echo ""
  echo -e "  ${RED}✗${NC} Service did not become active within ${WAIT_SECONDS}s"
  echo ""
  echo "  Recent logs:"
  journalctl -u "$SERVICE" -n 20 --no-pager | sed 's/^/    /'
  exit 1
fi
echo ""

# Step 5: Post-check
echo -e "${BLUE}[5/5]${NC} Post-check..."
if [[ -n "$POST_CHECK" ]]; then
  sleep 2  # give service a moment to fully initialize
  echo "  Running post-check: $POST_CHECK"
  if eval "$POST_CHECK" > /tmp/post-check-$$.out 2>&1; then
    echo -e "  ${GREEN}✓${NC} Post-check passed"
    cat /tmp/post-check-$$.out | sed 's/^/    /'
    rm -f /tmp/post-check-$$.out
  else
    echo -e "  ${RED}✗${NC} Post-check FAILED"
    cat /tmp/post-check-$$.out | sed 's/^/    /'
    rm -f /tmp/post-check-$$.out

    echo ""
    echo "  Recent logs (in case the post-check failure is a real problem):"
    journalctl -u "$SERVICE" -n 30 --no-pager | sed 's/^/    /'
    exit 1
  fi
else
  if systemctl is-active --quiet "$SERVICE"; then
    echo -e "  ${GREEN}✓${NC} Service is active"
  else
    echo -e "  ${RED}✗${NC} Service is NOT active"
    exit 1
  fi
fi
echo ""

echo "════════════════════════════════════════════════════════════════════"
echo -e " ${GREEN}✓ Restart of $SERVICE completed successfully${NC}"
echo "════════════════════════════════════════════════════════════════════"