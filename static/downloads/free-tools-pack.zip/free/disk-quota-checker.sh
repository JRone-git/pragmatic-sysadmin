#!/usr/bin/env bash
# =============================================================================
# disk-quota-checker.sh — Find top disk space users on shared systems
# Free tool from Pragmatic Sysadmin
# https://pragmaticsysadmin.help/shop/
# =============================================================================
# Usage:
#   ./disk-quota-checker.sh                    # scan /home, top 10
#   ./disk-quota-checker.sh -d /var/www -n 20  # custom dir, top 20
#   sudo ./disk-quota-checker.sh                # needed for accurate sizes
#
# Useful for:
#   - Finding who's filling up shared /home
#   - Auditing large Docker/container workloads
#   - Spotting log files that grew unexpectedly
# =============================================================================

set -euo pipefail

DIR="/home"
TOP_N=10

while [[ $# -gt 0 ]]; do
  case "$1" in
    -d) DIR="$2"; shift 2 ;;
    -n) TOP_N="$2"; shift 2 ;;
    -h|--help) sed -n '2,15p' "$0"; exit 0 ;;
    *) echo "Unknown flag: $1"; exit 1 ;;
  esac
done

if [[ ! -d "$DIR" ]]; then
  echo "Error: $DIR does not exist"
  exit 1
fi

if [[ $EUID -ne 0 ]]; then
  echo "Note: running as non-root, sizes may be inaccurate for files you can't read"
  echo "      Run with sudo for accurate totals"
fi

echo "════════════════════════════════════════════════════════════════════"
echo " Disk Usage by User/Directory — $DIR"
echo " $(date)"
echo "════════════════════════════════════════════════════════════════════"
echo ""

# Calculate size of each top-level subdir
echo "▼ Top $TOP_N by size in $DIR:"
echo ""
printf "%10s  %s\n" "SIZE" "PATH"
printf "%10s  %s\n" "----------" "----"

du -sh -d 1 "$DIR" 2>/dev/null | sort -hr | head -n "$TOP_N" | while IFS= read -r line; do
  size=$(echo "$line" | awk '{print $1}')
  path=$(echo "$line" | awk '{print $2}')
  printf "%10s  %s\n" "$size" "$path"
done

echo ""
echo "▼ Breakdown of largest:"
echo ""
largest=$(du -sh -d 1 "$DIR" 2>/dev/null | sort -hr | head -1 | awk '{print $2}')
if [[ -d "$largest" ]]; then
  echo "  Top 5 in $largest:"
  du -sh "$largest"/* 2>/dev/null | sort -hr | head -5 | sed 's/^/    /'
fi

echo ""
echo "════════════════════════════════════════════════════════════════════"
echo " Suggested actions"
echo "════════════════════════════════════════════════════════════════════"
echo ""
echo "  1. Contact the user with the largest directory"
echo "  2. Check if old logs can be rotated:    logrotate -f /etc/logrotate.conf"
echo "  3. Clean package cache:                  apt clean  (or yum clean all)"
echo "  4. Find large old files:                 find $DIR -size +100M -mtime +30"
echo "  5. Set up disk usage alerts:             /opt/health-check/quick-health-check.sh --quiet"
echo ""

# Auto-flag any user over 10GB
echo "▼ Users over 10GB (potential cleanup candidates):"
echo ""
found=0
du -sh -d 1 "$DIR" 2>/dev/null | sort -hr | head -20 | while IFS= read -r line; do
  size=$(echo "$line" | awk '{print $1}')
  size_bytes=$(echo "$size" | numfmt --from=iec 2>/dev/null || echo 0)
  if [[ $size_bytes -gt 10737418240 ]]; then  # 10GB
    path=$(echo "$line" | awk '{print $2}')
    echo "  ⚠ $path — $size"
    found=1
  fi
done
[[ $found -eq 0 ]] && echo "  None found"

echo ""
echo "════════════════════════════════════════════════════════════════════"