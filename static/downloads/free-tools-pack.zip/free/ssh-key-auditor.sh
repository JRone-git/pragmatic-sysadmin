#!/usr/bin/env bash
# =============================================================================
# ssh-key-auditor.sh — Audit SSH keys across user accounts
# Free tool from Pragmatic Sysadmin
# https://pragmaticsysadmin.help/shop/
# =============================================================================
# Usage:
#   ./ssh-key-auditor.sh              # scan /home
#   ./ssh-key-auditor.sh -d /home      # custom home dir
#   ./ssh-key-auditor.sh -u root,sysadmin  # specific users
#   sudo ./ssh-key-auditor.sh           # includes /root
#
# Reports:
#   - All SSH public keys (with fingerprints)
#   - Key type and length (warns on weak keys)
#   - Last modification date
#   - Suspicious patterns (e.g., command= keys, weak ciphers)
# =============================================================================

set -euo pipefail

HOME_DIR="/home"
SPECIFIC_USERS=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    -d) HOME_DIR="$2"; shift 2 ;;
    -u) SPECIFIC_USERS="$2"; shift 2 ;;
    -h|--help) sed -n '2,15p' "$0"; exit 0 ;;
    *) echo "Unknown flag: $1"; exit 1 ;;
  esac
done

# Colors
if [[ -t 1 ]]; then
  RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'
else
  RED=''; YELLOW=''; GREEN=''; BLUE=''; NC=''
fi

# Build user list
USERS=()
if [[ -n "$SPECIFIC_USERS" ]]; then
  IFS=',' read -ra USERS <<< "$SPECIFIC_USERS"
else
  if [[ -d "$HOME_DIR" ]]; then
    for d in "$HOME_DIR"/*; do
      [[ -d "$d" ]] && USERS+=("$(basename "$d")")
    done
  fi
  # Always include root if we can
  if [[ -d "/root/.ssh" ]] && [[ $EUID -eq 0 || -r "/root/.ssh" ]]; then
    USERS+=("root")
  fi
fi

if [[ ${#USERS[@]} -eq 0 ]]; then
  echo "No users found in $HOME_DIR"
  exit 1
fi

echo "════════════════════════════════════════════════════════════════════"
echo " SSH Key Audit Report"
echo " $(date)"
echo "════════════════════════════════════════════════════════════════════"
echo ""

TOTAL_KEYS=0
WEAK_KEYS=0
SUSPICIOUS=0

for user in "${USERS[@]}"; do
  if [[ "$user" == "root" ]]; then
    SSH_DIR="/root/.ssh"
    HOME_USER="/root"
  else
    SSH_DIR="$HOME_DIR/$user/.ssh"
    HOME_USER="$HOME_DIR/$user"
  fi

  [[ ! -d "$SSH_DIR" ]] && continue

  echo -e "${BLUE}User: $user${NC}"
  echo "  SSH dir: $SSH_DIR"

  # Check authorized_keys
  for keyfile in authorized_keys authorized_keys2; do
    f="$SSH_DIR/$keyfile"
    if [[ -f "$f" ]]; then
      echo ""
      echo "  $keyfile:"
      # Count keys
      key_count=$(grep -c "^ssh-" "$f" 2>/dev/null || echo 0)
      echo "    Total keys: $key_count"
      TOTAL_KEYS=$((TOTAL_KEYS + key_count))

      # Check each key
      grep "^ssh-" "$f" 2>/dev/null | while IFS= read -r key; do
        type=$(echo "$key" | awk '{print $1}')
        bits=$(echo "$key" | awk '{print $2}' | head -c 4)

        # Weak key warning
        if [[ "$type" == "ssh-dss" || "$type" == "ssh-rsa" && ${#key} -lt 500 ]]; then
          echo -e "    ${YELLOW}! Weak key: $type (consider upgrading to ed25519)${NC}"
        fi

        # Suspicious options check (command=, from= restrictions are valid but flag for review)
        if echo "$key" | grep -qE "(command=|from=|no-pty)"; then
          echo -e "    ${YELLOW}! Restricted key (review options)${NC}"
        fi
      done
    fi
  done

  # Check private keys (warn if world-readable)
  if [[ -d "$SSH_DIR" ]]; then
    private_keys=$(find "$SSH_DIR" -name "id_*" ! -name "*.pub" 2>/dev/null)
    if [[ -n "$private_keys" ]]; then
      echo ""
      echo "  Private keys:"
      echo "$private_keys" | while read -r pk; do
        perms=$(stat -c "%a" "$pk" 2>/dev/null || echo "??")
        if [[ "$perms" != "600" && "$perms" != "400" ]]; then
          echo -e "    ${RED}! $pk — permissions $perms (should be 600)${NC}"
        else
          echo -e "    ${GREEN}✓${NC} $pk — permissions $perms"
        fi
      done
    fi
  fi

  # Check known_hosts for old entries
  if [[ -f "$SSH_DIR/known_hosts" ]]; then
    host_count=$(wc -l < "$SSH_DIR/known_hosts" 2>/dev/null || echo 0)
    echo ""
    echo "  known_hosts: $host_count entr$([[ $host_count -ne 1 ]] && echo 'ies' || 'y')"
  fi

  echo ""
done

echo "════════════════════════════════════════════════════════════════════"
echo " Summary"
echo "════════════════════════════════════════════════════════════════════"
echo "  Users scanned: ${#USERS[@]}"
echo "  Total authorized keys: $TOTAL_KEYS"
echo ""
echo -e "  ${GREEN}✓${NC} = good"
echo -e "  ${YELLOW}!${NC} = review recommended"
echo -e "  ${RED}✗${NC} = security issue"
echo ""
echo "Recommendations:"
echo "  1. Replace any DSA or short RSA keys with ed25519"
echo "  2. Audit restricted keys (command=, from=) regularly"
echo "  3. Remove keys for users who no longer need access"
echo "  4. Consider using SSH certificates instead of authorized_keys"