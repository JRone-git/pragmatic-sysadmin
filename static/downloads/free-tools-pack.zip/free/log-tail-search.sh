#!/usr/bin/env bash
# =============================================================================
# log-tail-search.sh — Search log files for patterns with context
# Free tool from Pragmatic Sysadmin
# https://pragmaticsysadmin.help/shop/
# =============================================================================
# Usage:
#   ./log-tail-search.sh -p "Out of memory" -d /var/log
#   ./log-tail-search.sh -p "error" -f syslog,messages -n 200 -i
#   ./log-tail-search.sh -p "Failed password" -s 24h
#
# Flags:
#   -p PATTERN    Pattern to search for (required, case-sensitive unless -i)
#   -d DIR        Directory to search (default: /var/log)
#   -f FILES      Comma-separated list of filenames to search (default: auto)
#   -n LINES      Lines of context to show (default: 3)
#   -s TIMESPAN   Only search recent log: "1h", "24h", "7d" (default: all)
#   -i            Case-insensitive search
#   -r            Recursive into subdirs
#   -h            Help
# =============================================================================

set -euo pipefail

PATTERN=""
DIR="/var/log"
FILES=""
CONTEXT=3
TIMESPAN=""
INSENSITIVE=""
RECURSIVE=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    -p) PATTERN="$2"; shift 2 ;;
    -d) DIR="$2"; shift 2 ;;
    -f) FILES="$2"; shift 2 ;;
    -n) CONTEXT="$2"; shift 2 ;;
    -s) TIMESPAN="$2"; shift 2 ;;
    -i) INSENSITIVE="-i"; shift ;;
    -r) RECURSIVE="-r"; shift ;;
    -h|--help) sed -n '2,15p' "$0"; exit 0 ;;
    *) echo "Unknown flag: $1"; exit 1 ;;
  esac
done

if [[ -z "$PATTERN" ]]; then
  echo "Error: -p PATTERN is required"
  echo "Try: $0 -p 'error' -d /var/log"
  exit 1
fi

# Build find args
FIND_ARGS=("$DIR")
if [[ "$RECURSIVE" == "-r" ]]; then
  FIND_ARGS+=("")  # find handles recursion without -r in newer versions
fi
FIND_ARGS+=("-type" "f")

# Build name filter from FILES list
NAME_ARGS=()
if [[ -n "$FILES" ]]; then
  FIRST=true
  while IFS= read -r fname; do
    [[ -z "$fname" ]] && continue
    if [[ "$FIRST" == "true" ]]; then
      NAME_ARGS+=("(" "-name" "$fname")
      FIRST=false
    else
      NAME_ARGS+=("-o" "-name" "$fname")
    fi
  done < <(echo "$FILES" | tr ',' '\n')
  if [[ ${#NAME_ARGS[@]} -gt 0 ]]; then
    NAME_ARGS+=(")")
  fi
fi

# Time filter
TIME_ARGS=""
if [[ -n "$TIMESPAN" ]]; then
  unit="${TIMESPAN: -1}"
  value="${TIMESPAN%?}"
  case "$unit" in
    h) minutes=$((value * 60)) ;;
    d) minutes=$((value * 1440)) ;;
    m) minutes=$value ;;
    *) echo "Invalid timespan: $TIMESPAN (use 1h, 24h, 7d, 30m)"; exit 1 ;;
  esac
  TIME_ARGS="-mmin -$minutes"
fi

# Find files
if [[ ${#NAME_ARGS[@]} -gt 0 ]]; then
  mapfile -t LOG_FILES < <(find "${FIND_ARGS[@]}" "${NAME_ARGS[@]}" 2>/dev/null | head -50)
else
  mapfile -t LOG_FILES < <(find "$DIR" -type f \( -name "*.log" -o -name "syslog*" -o -name "messages*" \) 2>/dev/null | head -50)
fi

if [[ ${#LOG_FILES[@]} -eq 0 ]]; then
  echo "No log files found in $DIR"
  exit 1
fi

# Build grep args
GREP_FLAGS=(-n $INSENSITIVE -B "$CONTEXT" -A "$CONTEXT" --color=always)
[[ -n "$TIME_ARGS" ]] && GREP_FLAGS+=($TIME_ARGS)

TOTAL_HITS=0
for log in "${LOG_FILES[@]}"; do
  # Skip if file not modified within timespan (when timespan specified)
  if [[ -n "$TIME_ARGS" ]] && ! find "$log" $TIME_ARGS -type f 2>/dev/null | grep -q .; then
    continue
  fi

  hits=$(grep "${GREP_FLAGS[@]}" -F "$PATTERN" "$log" 2>/dev/null || true)
  if [[ -n "$hits" ]]; then
    count=$(echo "$hits" | grep -c "^" || echo 0)
    TOTAL_HITS=$((TOTAL_HITS + count))

    echo ""
    echo "════════════════════════════════════════════════════════════════════"
    echo "  $log  ($count match$([ "$count" -ne 1 ] && echo "es"))"
    echo "════════════════════════════════════════════════════════════════════"
    echo "$hits"
  fi
done

echo ""
echo "────────────────────────────────────────────────────────────────────"
echo "Total matches: $TOTAL_HITS across ${#LOG_FILES[@]} log file(s)"
echo "Pattern: $PATTERN"
[[ -n "$TIMESPAN" ]] && echo "Time filter: $TIMESPAN"
exit 0