#!/usr/bin/env bash
# =============================================================================
# ssl-cert-checker.sh — Check SSL certificate expiry for one or more domains
# Free tool from Pragmatic Sysadmin
# https://pragmaticsysadmin.help/shop/
# =============================================================================
# Usage:
#   ./ssl-cert-checker.sh google.com github.com prag mati csysadmin.help
#   ./ssl-cert-checker.sh -f domains.txt
#   cat domains.txt | ./ssl-cert-checker.sh -
#
# Exit codes:
#   0 = all certs OK (>30 days)
#   1 = at least one cert expiring within 30 days
#   2 = at least one cert expiring within 7 days OR already expired
# =============================================================================

set -euo pipefail

WARN_DAYS=30
CRIT_DAYS=7

# Colors
if [[ -t 1 ]]; then
  RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; NC='\033[0m'
else
  RED=''; YELLOW=''; GREEN=''; NC=''
fi

# Parse args
DOMAINS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    -f|--file)
      while IFS= read -r line; do
        [[ -n "$line" && ! "$line" =~ ^# ]] && DOMAINS+=("$line")
      done < "$2"
      shift 2 ;;
    -w|--warn) WARN_DAYS="$2"; shift 2 ;;
    -c|--crit) CRIT_DAYS="$2"; shift 2 ;;
    -h|--help)
      sed -n '2,12p' "$0"; exit 0 ;;
    -)  # stdin
      while IFS= read -r line; do
        [[ -n "$line" && ! "$line" =~ ^# ]] && DOMAINS+=("$line")
      done
      shift ;;
    *) DOMAINS+=("$1"); shift ;;
  esac
done

if [[ ${#DOMAINS[@]} -eq 0 ]]; then
  echo "Usage: $0 domain1 [domain2 ...]"
  echo "       $0 -f domains.txt"
  echo ""
  echo "Flags:"
  echo "  -f FILE   Read domains from file (one per line)"
  echo "  -w DAYS   Warning threshold (default: 30)"
  echo "  -c DAYS   Critical threshold (default: 7)"
  exit 1
fi

NOW_EPOCH=$(date +%s)
WORST_EXIT=0

printf "%-40s %-15s %-15s\n" "DOMAIN" "EXPIRES" "DAYS LEFT"
printf "%-40s %-15s %-15s\n" "------" "-------" "--------"

for domain in "${DOMAINS[@]}"; do
  domain=$(echo "$domain" | tr -d '[:space:]')
  [[ -z "$domain" ]] && continue

  # Get cert expiry — try openssl s_client
  cert_text=$(echo | timeout 10 openssl s_client -servername "$domain" -connect "${domain}:443" 2>/dev/null | openssl x509 -noout -enddate 2>/dev/null) || {
    printf "%-40s ${RED}%-15s${NC} %-15s\n" "$domain" "CONNECT-FAIL" "-"
    WORST_EXIT=2
    continue
  }

  expiry_str=$(echo "$cert_text" | cut -d= -f2)
  expiry_epoch=$(date -d "$expiry_str" +%s 2>/dev/null) || {
    printf "%-40s ${RED}%-15s${NC} %-15s\n" "$domain" "PARSE-FAIL" "-"
    WORST_EXIT=2
    continue
  }

  days_left=$(( (expiry_epoch - NOW_EPOCH) / 86400 ))
  expiry_short=$(date -d "$expiry_str" +"%Y-%m-%d" 2>/dev/null)

  if [[ $days_left -lt 0 ]]; then
    color=$RED; status="EXPIRED"
    WORST_EXIT=2
  elif [[ $days_left -lt $CRIT_DAYS ]]; then
    color=$RED
    [[ $WORST_EXIT -lt 2 ]] && WORST_EXIT=2
  elif [[ $days_left -lt $WARN_DAYS ]]; then
    color=$YELLOW
    [[ $WORST_EXIT -lt 1 ]] && WORST_EXIT=1
  else
    color=$GREEN
  fi

  printf "%-40s ${color}%-15s${NC} ${color}%-15s${NC}\n" "$domain" "${expiry_short:--}" "${days_left} days"
done

echo ""
if [[ $WORST_EXIT -eq 0 ]]; then
  echo -e "${GREEN}✓ All certificates are healthy${NC}"
elif [[ $WORST_EXIT -eq 1 ]]; then
  echo -e "${YELLOW}! At least one cert expires within ${WARN_DAYS} days${NC}"
else
  echo -e "${RED}✗ At least one cert expires within ${CRIT_DAYS} days or is expired${NC}"
fi

exit $WORST_EXIT