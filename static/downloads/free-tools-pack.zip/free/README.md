# Pragmatic Sysadmin Free Tools Pack

Five battle-tested bash scripts that solve real sysadmin problems.

No dependencies. No installation. No SaaS. Just download, read, run.

## What's included

### 🔒 ssl-cert-checker.sh — SSL Certificate Expiry Checker

Find certificates about to expire before they break your site.

```bash
./ssl-cert-checker.sh prag mati csysadmin.help github.com google.com
./ssl-cert-checker.sh -f domains.txt
```

Exit codes: `0` = all OK, `1` = expiring within 30 days, `2` = expiring within 7 days or already expired. Perfect for cron + monitoring.

### 🔍 log-tail-search.sh — Log Pattern Search with Context

Search multiple log files for patterns with surrounding context lines.

```bash
./log-tail-search.sh -p "Out of memory" -d /var/log
./log-tail-search.sh -p "Failed password" -s 24h -i
./log-tail-search.sh -p "error" -f syslog,messages -n 5
```

Smart features: time-range filter (`-s 1h`, `-s 24h`, `-s 7d`), case-insensitive search, color output, file-by-file grouping.

### 🔑 ssh-key-auditor.sh — SSH Key Security Audit

Audit SSH keys across all user accounts. Find weak keys, suspicious restrictions, and world-readable private keys.

```bash
./ssh-key-auditor.sh                  # scan /home
sudo ./ssh-key-auditor.sh              # includes /root
./ssh-key-auditor.sh -u alice,bob     # specific users
```

Reports every authorized key with type/length, flags weak (DSA, short RSA) keys, finds private keys with bad permissions.

### 📊 disk-quota-checker.sh — Find Disk Space Hogs

Find who's using the most disk on a shared system. Auto-flags users over 10GB.

```bash
./disk-quota-checker.sh                    # scan /home, top 10
sudo ./disk-quota-checker.sh               # accurate sizes for all users
./disk-quota-checker.sh -d /var/www -n 20  # custom dir
```

### 🔄 service-restart-tamer.sh — Safe Service Restarts

Restart services safely with pre-checks, post-checks, and rollback guidance if something goes wrong.

```bash
./service-restart-tamer.sh nginx
./service-restart-tamer.sh postgresql --wait 30
./service-restart-tamer.sh my-app --pre-check "curl -s http://localhost:8080/health"
```

Verifies service comes back up, runs your custom health check, prints recent logs if anything fails.

---

## Why these are free

Because they should be. They're useful, they're small, they're well-tested. Give them to anyone who needs them.

The paid toolkits in [/shop/](/shop/) are bigger, more comprehensive, and come with deeper guides and decision trees. Start here, graduate there when you outgrow the free tools.

## Installation

```bash
# Download the pack
curl -O https://pragmaticsysadmin.help/downloads/free-tools-pack.zip
unzip free-tools-pack.zip

# Make executable
chmod +x *.sh

# Run any tool with --help for usage
./ssl-cert-checker.sh --help
```

## License

MIT — use, modify, redistribute.

## Support

Found a bug? Have a feature request?

Email: pragmatic@pragmaticsysadmin.help

## More tools

Looking for the comprehensive toolkits? See [/shop/](/shop/) for the paid versions:

- **The 5-Minute Server Health Check Toolkit** ($9) — the "do everything" companion to these free scripts
- **The Friday Backup Audit Toolkit** ($19, coming soon) — backup verification scripts
- **Home Lab Starter Scripts** ($9, coming soon) — get a homelab running in a weekend

---

Made with care by [Pragmatic Sysadmin](https://pragmaticsysadmin.help) —
helping sysadmins sleep better since 2010.